-- Investment module (savings theke invest)
-- phpMyAdmin e finance_api database select kore ei SQL ta run koro.
-- (age savings.sql ar expenses.sql import kora thakte hobe)

-- 1) Loan deya
CREATE TABLE IF NOT EXISTS loans (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    member_id INT UNSIGNED DEFAULT NULL,                   -- member hole members.id, na hole NULL
    borrower_name VARCHAR(150) NOT NULL,                   -- je loan nilo
    borrower_phone VARCHAR(20) DEFAULT NULL,
    principal DECIMAL(12,2) NOT NULL,                      -- je taka loan deya hoyechhe
    interest_rate DECIMAL(6,2) NOT NULL DEFAULT 0,         -- bochorey simple interest %
    loan_date DATE NOT NULL,
    due_date DATE DEFAULT NULL,                            -- ferot-er shomoyshima (optional)
    note VARCHAR(255) DEFAULT NULL,
    created_at DATETIME DEFAULT NULL,
    updated_at DATETIME DEFAULT NULL,
    deleted_at DATETIME DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Loan ferot: protita ferot-e koto principal ar koto interest ashlo alada kore rakha hoy
CREATE TABLE IF NOT EXISTS loan_payments (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    loan_id INT UNSIGNED NOT NULL,
    principal_amount DECIMAL(12,2) NOT NULL DEFAULT 0,     -- mul taka ferot
    interest_amount DECIMAL(12,2) NOT NULL DEFAULT 0,      -- interest hishebe pawa
    payment_date DATE NOT NULL,
    note VARCHAR(255) DEFAULT NULL,
    created_at DATETIME DEFAULT NULL,
    updated_at DATETIME DEFAULT NULL,
    deleted_at DATETIME DEFAULT NULL,
    KEY idx_loan_payments_loan (loan_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2) Jomi / Beboshay / Gold
CREATE TABLE IF NOT EXISTS assets (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    asset_type VARCHAR(20) NOT NULL,                       -- land / business / gold
    title VARCHAR(150) NOT NULL,                           -- jemon: "Mirpur 5 katha jomi", "Gold 3 bhori"
    details VARCHAR(255) DEFAULT NULL,                     -- poriman/bibaron (jemon 3 bhori, 5 decimal)
    amount DECIMAL(12,2) NOT NULL,                         -- invest kora taka
    invest_date DATE NOT NULL,
    status VARCHAR(10) NOT NULL DEFAULT 'active',          -- active / sold
    sale_amount DECIMAL(12,2) DEFAULT NULL,                -- bikri-r daam
    sale_date DATE DEFAULT NULL,
    note VARCHAR(255) DEFAULT NULL,
    created_at DATETIME DEFAULT NULL,
    updated_at DATETIME DEFAULT NULL,
    deleted_at DATETIME DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
